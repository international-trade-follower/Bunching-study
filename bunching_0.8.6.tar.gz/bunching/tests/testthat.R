library(testthat)
library(bunching)

test_check("bunching")
