# bunching 0.8.6

## Minor changes
- fixed examples
- updated vignette references
- updated tests
- updated deprecated ggplot2 options
- made documentation compatible with HTML5

# bunching 0.8.4

## Major changes
- Initial release
