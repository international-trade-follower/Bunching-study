if(getRversion() >= "2.15.1") utils::globalVariables(c("bin", "freq_orig", "cf", "actual",
                                                       "z", "bunch_region", "key", "value", "cf_graph"))
